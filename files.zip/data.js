/* ============================================================
   NARDO — data.js
   Fuente única de datos del catálogo. Por ahora los productos
   viven acá como semilla; en la Etapa 9 (panel de admin) este
   mismo storage se va a poder editar desde la carga de producto.
   ============================================================ */

const STORE_KEYS = {
  products: "nardo_products",
  categories: "nardo_categories",
  brands: "nardo_brands",
  families: "nardo_families",
  cart: "nardo_cart",
};

const SEED_CATEGORIES = [
  { id: "hombre", nombre: "Hombre", texto: "Maderas, especias y cuero. Fragancias con carácter." },
  { id: "mujer", nombre: "Mujer", texto: "Florales, gourmand y orientales de autor." },
  { id: "unisex", nombre: "Unisex", texto: "Composiciones que no piden permiso para el género." },
  { id: "arabes", nombre: "Árabes", texto: "Oud, ámbar y resinas. Intensidad e ideas." },
  { id: "niche", nombre: "Niche", texto: "Casas independientes, tiradas cortas, otra escala." },
];

const SEED_FAMILIES = [
  "Floral", "Amaderada", "Cítrica", "Frutal",
  "Gourmand", "Oriental", "Especiada", "Acuática", "Almizclada",
];

const SEED_BRANDS = [
  "Dior", "Chanel", "Paco Rabanne", "Versace", "Lattafa",
  "Carolina Herrera", "Giorgio Armani", "Montblanc", "Yves Saint Laurent", "Afnan",
];

const SEED_PRODUCTS = [
  {
    id: "p01", nombre: "Sauvage", marca: "Dior", categoria: "hombre",
    familia: "Especiada", genero: "Hombre", concentracion: "EDT",
    tamano: "100 ml", precio: 145000, precioAnterior: null,
    stock: 14, stockMinimo: 5, destacado: true, oferta: false, nuevo: false,
    tono: "amber",
  },
  {
    id: "p02", nombre: "Invictus", marca: "Paco Rabanne", categoria: "hombre",
    familia: "Acuática", genero: "Hombre", concentracion: "EDT",
    tamano: "100 ml", precio: 120000, precioAnterior: 150000,
    stock: 9, stockMinimo: 5, destacado: false, oferta: true, nuevo: false,
    tono: "blue",
  },
  {
    id: "p03", nombre: "Coco Mademoiselle", marca: "Chanel", categoria: "mujer",
    familia: "Floral", genero: "Mujer", concentracion: "EDP",
    tamano: "50 ml", precio: 210000, precioAnterior: null,
    stock: 6, stockMinimo: 4, destacado: true, oferta: false, nuevo: false,
    tono: "rose",
  },
  {
    id: "p04", nombre: "Good Girl", marca: "Carolina Herrera", categoria: "mujer",
    familia: "Gourmand", genero: "Mujer", concentracion: "EDP",
    tamano: "80 ml", precio: 175000, precioAnterior: 205000,
    stock: 3, stockMinimo: 4, destacado: false, oferta: true, nuevo: false,
    tono: "wine",
  },
  {
    id: "p05", nombre: "Khamrah", marca: "Lattafa", categoria: "arabes",
    familia: "Gourmand", genero: "Unisex", concentracion: "EDP",
    tamano: "100 ml", precio: 65000, precioAnterior: null,
    stock: 22, stockMinimo: 6, destacado: true, oferta: false, nuevo: true,
    tono: "amber",
  },
  {
    id: "p06", nombre: "Asad", marca: "Lattafa", categoria: "arabes",
    familia: "Amaderada", genero: "Hombre", concentracion: "EDP",
    tamano: "100 ml", precio: 58000, precioAnterior: 72000,
    stock: 17, stockMinimo: 6, destacado: false, oferta: true, nuevo: false,
    tono: "olive",
  },
  {
    id: "p07", nombre: "Eros", marca: "Versace", categoria: "hombre",
    familia: "Cítrica", genero: "Hombre", concentracion: "EDT",
    tamano: "100 ml", precio: 110000, precioAnterior: null,
    stock: 11, stockMinimo: 5, destacado: false, oferta: false, nuevo: false,
    tono: "blue",
  },
  {
    id: "p08", nombre: "Black Opium", marca: "Yves Saint Laurent", categoria: "mujer",
    familia: "Oriental", genero: "Mujer", concentracion: "EDP",
    tamano: "50 ml", precio: 195000, precioAnterior: null,
    stock: 8, stockMinimo: 4, destacado: true, oferta: false, nuevo: false,
    tono: "ink",
  },
  {
    id: "p09", nombre: "Explorer", marca: "Montblanc", categoria: "unisex",
    familia: "Amaderada", genero: "Unisex", concentracion: "EDP",
    tamano: "60 ml", precio: 98000, precioAnterior: null,
    stock: 0, stockMinimo: 4, destacado: false, oferta: false, nuevo: true,
    tono: "olive",
  },
  {
    id: "p10", nombre: "Supremacy Silver", marca: "Afnan", categoria: "niche",
    familia: "Almizclada", genero: "Unisex", concentracion: "EDP",
    tamano: "100 ml", precio: 72000, precioAnterior: 89000,
    stock: 13, stockMinimo: 5, destacado: true, oferta: true, nuevo: false,
    tono: "rose",
  },
  {
    id: "p11", nombre: "Stronger With You", marca: "Giorgio Armani", categoria: "hombre",
    familia: "Especiada", genero: "Hombre", concentracion: "EDT",
    tamano: "50 ml", precio: 105000, precioAnterior: null,
    stock: 5, stockMinimo: 5, destacado: false, oferta: false, nuevo: true,
    tono: "amber",
  },
  {
    id: "p12", nombre: "Libre", marca: "Yves Saint Laurent", categoria: "mujer",
    familia: "Floral", genero: "Mujer", concentracion: "EDP",
    tamano: "50 ml", precio: 188000, precioAnterior: null,
    stock: 2, stockMinimo: 4, destacado: false, oferta: false, nuevo: false,
    tono: "ink",
  },
];

/* Inicializa localStorage sólo si todavía no existe nada guardado,
   para no pisar cambios que haga el panel de admin más adelante. */
function initStore() {
  if (!localStorage.getItem(STORE_KEYS.products)) {
    localStorage.setItem(STORE_KEYS.products, JSON.stringify(SEED_PRODUCTS));
  }
  if (!localStorage.getItem(STORE_KEYS.categories)) {
    localStorage.setItem(STORE_KEYS.categories, JSON.stringify(SEED_CATEGORIES));
  }
  if (!localStorage.getItem(STORE_KEYS.brands)) {
    localStorage.setItem(STORE_KEYS.brands, JSON.stringify(SEED_BRANDS));
  }
  if (!localStorage.getItem(STORE_KEYS.families)) {
    localStorage.setItem(STORE_KEYS.families, JSON.stringify(SEED_FAMILIES));
  }
  if (!localStorage.getItem(STORE_KEYS.cart)) {
    localStorage.setItem(STORE_KEYS.cart, JSON.stringify([]));
  }
}

function getProducts() {
  return JSON.parse(localStorage.getItem(STORE_KEYS.products) || "[]");
}
function getCategories() {
  return JSON.parse(localStorage.getItem(STORE_KEYS.categories) || "[]");
}
function getBrands() {
  return JSON.parse(localStorage.getItem(STORE_KEYS.brands) || "[]");
}

function formatARS(n) {
  return n.toLocaleString("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 });
}

function stockEstado(p) {
  if (p.stock <= 0) return { label: "Sin stock", cls: "stock-out" };
  if (p.stock <= p.stockMinimo) return { label: "Poco stock", cls: "stock-low" };
  return { label: "Disponible", cls: "stock-ok" };
}
