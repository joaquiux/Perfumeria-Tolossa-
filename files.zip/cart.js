/* ============================================================
   NARDO — cart.js
   Carrito mínimo para la Etapa 1: agregar desde una tarjeta y
   ver el contador en el header. La página /carrito con quitar,
   cambiar cantidad, etc. se arma en la Etapa 5.
   ============================================================ */

function getCart() {
  return JSON.parse(localStorage.getItem(STORE_KEYS.cart) || "[]");
}

function saveCart(cart) {
  localStorage.setItem(STORE_KEYS.cart, JSON.stringify(cart));
  updateCartBadge();
}

function addToCart(productId, cantidad = 1) {
  const cart = getCart();
  const linea = cart.find((l) => l.id === productId);
  if (linea) {
    linea.cantidad += cantidad;
  } else {
    cart.push({ id: productId, cantidad });
  }
  saveCart(cart);
}

function cartCount() {
  return getCart().reduce((acc, l) => acc + l.cantidad, 0);
}

function updateCartBadge() {
  const badge = document.querySelector("[data-cart-count]");
  if (!badge) return;
  const count = cartCount();
  badge.textContent = count;
  badge.hidden = count === 0;
}

let toastTimer = null;
function showToast(message) {
  const toast = document.querySelector("[data-toast]");
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add("is-visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("is-visible"), 2600);
}
